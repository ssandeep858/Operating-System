#include <stdio.h>
#include<stdlib.h>

#include <string.h>

#include <stdbool.h>

int main() {
  //String to store the input CommandLines
  char str[1000],temp[1000];
  //String to store all commands for output
  char cmd[1000] = "None";
  //used in strtok_r for tokenising "str"
  char pipe[] = "|";
  //same a pipe but for tokenising the whole command into command and arguments
  char args[] = " ";
  //To store value if Background is present or not
  bool backG = false;
  //We will check if its first Input file or not
  bool firstI = true;
  //Similiar to firstI but for output files
  bool firstO = true;
  //To check if we are putting first command into cmd
  bool firstC = true;
  //Token number for looking if token in not an argument but only command
  int TokNo;
  //variable to store input files name;
  char inputfile[1000] = "None";
  //similiar to inputfile but for output files
  char outputfile[1000] = "None";
  
  int Error = 0;
  int pipecount = 0;
  int pipeNo = 0;
  int i=0;
  int j=0;
  
 printf("IUPUI SHELL \n ");
 printf("Enter the input: ");
  //getting whole string from user.
	scanf("%[^\n]%*c", str);
	
	
	for( j=0;j<1000;j++)
	{
			if(strcmp(str,"quit")==0){
				printf("exiting the shell ..... \n ");
				exit(0);}
else {
 
  strcpy(temp,str);
  for (i=0;i<strlen(str);i++){
    if(str[i] == '|'){
    	if(str[i-1]==0){
    		Error = 3;
    	}else if(str[i+1] == 0){
    		Error = 4;
    	}
        pipecount++;
    }
  }
  pipecount+=1;
  //context for strtok_r() as we are using nested  tokenising. We cant use strtok()
  char * pipeContext, * argsContext;
  
  //Converting str into tokens
  char * pipeToken = strtok_r(str, pipe, &pipeContext);
  if(Error == 0)
  while (pipeToken != NULL) {
    TokNo = 0;
    pipeNo++;
    char * argToken = strtok_r(pipeToken, args, &argsContext);
	
	if(Error == 0)
    while (argToken != NULL) {

      TokNo++;

      if (strcmp(argToken, "<") == 0 || (strcmp(argToken, "<<") == 0)) {
        argToken = strtok_r(NULL, args, & argsContext);
        if(pipeNo != 1){
        	Error = 6;
        	break;
        }
        if(argToken == NULL){
        	Error = 1;
        	break;
        }
        if (firstI) {
          firstI = false;
          //replacing "NONE" from input file. similiarly for every other symbol
          strcpy(inputfile, argToken);
        } else {
          strcat(inputfile, ", ");
          strcat(inputfile, argToken);
        }
      } else if (strcmp(argToken, ">") == 0 || (strcmp(argToken, ">>") == 0)) {
        argToken = strtok_r(NULL, args, & argsContext);
        if(pipeNo != pipecount){
        	Error = 7;
        	break;
        }
        if(argToken == NULL){
        	Error = 2;
        	break;
        }
        if (firstO) {
          firstO = false;
          strcpy(outputfile, argToken);
        } else {
          strcat(outputfile, ", ");
          strcat(outputfile, argToken);
        }
      } else if (strcmp(argToken, "&") == 0) {
		if(pipeNo == pipecount && temp[strlen(temp) - 1] == '&'){
			 backG = true;
        argToken = strtok_r(NULL, args, & argsContext);
		}else{
				Error = 5;
			break;
		}
		

      } else {
          //Here we are just taking first token i.e., our command
        if (TokNo == 1) {
          if (firstC) {
            firstC = false;
            strcpy(cmd, argToken);
          } else {
            strcat(cmd, ", ");
            strcat(cmd, argToken);
          }
        }else{
         strcat(cmd, " ");
            strcat(cmd, argToken);
}
      }

      argToken = strtok_r(NULL, args, & argsContext);
    }

    pipeToken = strtok_r(NULL, pipe, & pipeContext);

  }
  
  switch(Error){
  	case 0 :  printf("Commands : %s \n", cmd);
  printf("Input file : %s \n", inputfile);
  printf("Output file : %s \n", outputfile);
  printf("Background or not : %s \n", backG ? "Yes" : "No");
  break;
    case 1 : printf("Error : < or << is not followed  by a filename. \n");break;
    case 2 : printf("Error : > or >> is not followed  by a filename. \n"); break;
    case 3 : printf("Error : pip with no proceeding command. \n");break;
    case 4 : printf("Error : pip with no succeding command. \n"); break;
    case 5 : printf("Error : background symbol is not in the end. \n"); break;
    case 6 : printf("Error : input redirct after a pip; make sure only the first subcommand have < \n"); break;
    case 7 : printf("Error : input redirct after a pip; make sure only the last subcommand have > \n"); break;
    default : printf("SYSTEM FAILURE \n"); break;
  }

 main();
 }  
  

}}
