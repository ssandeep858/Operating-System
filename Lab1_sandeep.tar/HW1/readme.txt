1.C code is written in final.c file.
2.Makefile creates a executable file with the name of "hw1"


BUILD INFORMATION 

1. run make 
2. executable file hw1 will be made .
3. type ./hw1 and press enter (you will enter the shell ).
4. test for commands untill you press "quit".
5. shell will exit on typing quit.


TEST CASES
1.
IUPUI SHELL
 cat < aaa | more | more | grep 2 | sort | head | wc > bbb &			//basic example specified in assignment 
Commands : cat, more, more, grep 2, sort, head, wc
Input file : aaa
Output file : bbb
Background or not : Yes
2.
IUPUI SHELL									// exiting the shell 
 Enter the input: quit
exiting the shell .....

3.
IUPUI SHELL
fakecmd arg1 arg2
Commands : fakecmd arg1 arg2
Input file : None
Output file : None
Background or not : No
4.
 IUPUI SHELL                                                                     // error messages 
 Enter the input: |
Error : pip with no proceeding command.
5.
IUPUI SHELL                                                                       // no command after pipe 
 Enter the input: cat |
Error : pip with no succeding command.

6.IUPUI SHELL									  // background should be a last 
 Enter the input: cat & | more
Error : background symbol is not in the end.

7.IUPUI SHELL									  // output should be in the last and input at starting 
 Enter the input: output > a.txt | cat
Error : input redirct after a pip; make sure only the last subcommand have >
