#include <stdio.h>

#include<stdlib.h>

#include <string.h>

#include <stdbool.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <unistd.h>
void deploy(char **no_of_arg,char inputfile[],char outputfile[])
{
    int copy2, copy1, i;
  int pipefd[2];
  

  i = pipe(pipefd);
  if (i < 0) {
    perror("pipe"); exit(1);
  }


  if (fork() == 0) {
     
     
    //First child:
    if (dup2(pipefd[1], 1) != 1) {
      perror("dup2");
      exit(1);
    }    
    close(pipefd[1]);
    close(pipefd[0]);
    if(strcmp(inputfile,"None")!=0)
    {
    pipefd[0] = open(inputfile, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    }
    if(execvp(*no_of_arg, no_of_arg) < 0 ) {
      perror("execvp");
    }
  } else if (fork() == 0) {
      
        
    //Second child:
    if (dup2(pipefd[0], 0) != 0) {   
      perror("dup2");
      exit(1);
    }   
    close(pipefd[1]);
    close(pipefd[0]);
    if(strcmp(outputfile,"None")!=0)
    {
    pipefd[1]=open(outputfile, O_WRONLY | O_TRUNC | O_CREAT, 0644);
    }
    if(execvp(*no_of_arg, no_of_arg) < 0) {
      perror("execvp"); exit(1);
    }
  } else {
    //The parent:
    
    close(pipefd[1]);
    close(pipefd[0]);
    wait(&copy1);
    wait(&copy2);
    if (WEXITSTATUS(copy1) || WEXITSTATUS(copy2)) {
      fprintf(stderr, "performed" "\n");
    }
  }
}
void  parse(char *input_by_user, char **no_of_arg)
{
     while (*input_by_user != '\0') {        
          while (*input_by_user == ' ' || *input_by_user == '\t' || *input_by_user == '\n' )
               *input_by_user++ = '\0';    
          *no_of_arg++ = input_by_user;          
          while (*input_by_user != '\0' && *input_by_user != ' ' && 
                 *input_by_user != '\t' && *input_by_user != '\n') 
               input_by_user++;             
     }
     *no_of_arg = '\0';                 
}


int main() {
	do{
  //String to store the input CommandInput_by_users
  char str[1000],temp[1000];
  //String to store all commands for output
  char cmd[1000] = "None";
  //used in strtok_r for tokenising "str"
  char pipec[] = "|";
  //same a pipe but for tokenising the whole command into command and arguments
  char args[] = " ";
  //To store value if Background is present or not
  bool backG = false;
  //We will check if its first Input file or not
  bool firstI = true;
  //Similiar to firstI but for output files
  bool firstO = true;
  //To check if we are putting first command into cmd
  bool firstC = true;
  //Token number for looking if token in not an argument but only command
  int TokNo;
  //variable to store input files name;
  char inputfile[1000] = "None";
  //similiar to inputfile but for output files
  char outputfile[1000] = "None";
  
  int Error = 0;
  int pipecount = 0;
  int pipeNo = 0;
  
   printf ("IUPUI SHELL \n ");
  printf ("Enter the input: ");
  
  
  //geeting whole string from user.
scanf ("%[^\n]%*c", str);
strcpy(temp,str);

if(strcmp(str,"exit") ==0 ){
	printf ("Exiting shell ");
	exit(0);
}
  int i;
  for(i=0;i<strlen(str);i++){
    if(str[i] == '|'){
    	if(str[i-1]=='\0'){
    		Error = 3;
    	}else if(str[i+1] =='\0'){
    		Error = 4;
    	}
        pipecount++;
    }
  }
  
  int pipefd[2];
	  if (pipe(pipefd) < 0)
	    {
	      perror ("pipe error. exiting.....");
	      exit (0);
	    }
	    
  pipecount+=1;
  //context for strtok_r() as we are using nested  tokenising. We cant use strtok()
  char * pipeContext, * argsContext;
  
  //Converting str into tokens
  char * pipeToken = strtok_r(str, pipec, &pipeContext);
  if(Error == 0)
  while (pipeToken != NULL) {
    TokNo = 0;
    pipeNo++;
    
    
    char * argToken = strtok_r(pipeToken, args, &argsContext);
	
	if(Error == 0)
    while (argToken != NULL) {

      TokNo++;
      
      if (strcmp(argToken, "<") == 0 || (strcmp(argToken, "<<") == 0)) {
        argToken = strtok_r(NULL, args, & argsContext);
      
        if(pipeNo != 1){
        	Error = 6;
        	break;
        }
        if(argToken == NULL){
        	Error = 1;
        	break;
        }
        if (firstI) {
          firstI = false;
          //replacing "NONE" from input file. similiarly for every other symbol
          strcpy(inputfile, argToken);
           
        } else {
          strcat(inputfile, ", ");
          strcat(inputfile, argToken);
        }
      } else if (strcmp(argToken, ">") == 0 || (strcmp(argToken, ">>") == 0)) {
        argToken = strtok_r(NULL, args, & argsContext);
        
        
        if(pipeNo != pipecount){
        	Error = 7;
        	break;
        }
        if(argToken == NULL){
        	Error = 2;
        	break;
        }
        if (firstO) {
          firstO = false;
          strcpy(outputfile, argToken);
        } else {
          strcat(outputfile, ", ");
          strcat(outputfile, argToken);
        }
      } else if (strcmp(argToken, "&") == 0) {
		if(pipeNo == pipecount && temp[strlen(temp) - 1] == '&'){
			 backG = true;
        argToken = strtok_r(NULL, args, & argsContext);
		}

      } else {
          //Here we are just taking first token i.e., our command
        if (TokNo == 1) {
          if (firstC) {
            firstC = false;
            strcpy(cmd, argToken);
          } else {
            strcat(cmd, ", ");
            strcat(cmd, argToken);
          }
        }else{
         strcat(cmd, " ");
            strcat(cmd, argToken);
}
      }

      argToken = strtok_r(NULL, args, & argsContext);
    }

    pipeToken = strtok_r(NULL, "|", & pipeContext);

  }
  
  switch(Error){
  	case 0 : if(backG==true)
  	{
  	    printf("background process and process id = %d \n",getpid());
  	    break;
  	}
  char  *no_of_arg[64];  
  int k =0;
  while(temp[k]!='\0'){
  if( temp[k] == '\n') 
     temp[k] = '\0';
     k++;
     if(k==strlen(temp) -1)
     break;}
  parse(temp, no_of_arg);      
  deploy(no_of_arg,inputfile,outputfile);
  
  
  break;
    case 1 : printf("Error : < or << is not followed  by a filename. \n");break;
    case 2 : printf("Error : > or >> is not followed  by a filename. \n"); break;
    case 3 : printf("Error : pip with no proceeding command. \n");break;
    case 4 : printf("Error : pip with no succeding command. \n"); break;
    
    case 5 : printf("Error : input redirct after a pip; make sure only the first subcommand have < \n"); break;
    case 6 : printf("Error : input redirct after a pip; make sure only the last subcommand have > \n"); break;
    default : printf("SYSTEM FAILURE \n"); break;
  }
  
  
  
  
  
  }while(true);
  return 0;
}




