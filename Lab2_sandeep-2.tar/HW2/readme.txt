1.C code is written in hw2.c file.
2.Makefile creates a executable file with the name of "hw2"
3.Tried implementing multiple pipes to an extend and this is the maximum that i
could get this shell working .

BUILD INFORMATION 

1. run make 
2. executable file hw1 will be made .
3. type ./hw2 and press enter (you will enter the shell ).
4. test for commands untill you press "quit".
5. shell will exit on typing exit.

"NEW FILES CAN BE SEEN AFTER WE EXIT THE SHELL BY TYPING exit "

TEST CASES(background process and all error cases ae working but multiple pipes work to an extend  )
SINGLE COMMANDS 
1.IUPUI SHELL
 Enter the input: grep printf | sort | more &
background process and process id = 200858

2.IUPUI SHELL
Enter the input: ls
hw2  hw2.c  Makefile  readme.txt

3.
IUPUI SHELL									 Enter the input: ls -lh
total 32K
-rwxr-xr-x 1 singh96 students  14K Oct  3 15:34 hw2
-rw-r--r-- 1 singh96 students 6.4K Oct  3 15:18 hw2.c
-rw-r--r-- 1 singh96 students   29 Oct  3 15:33 Makefile
-rw-r--r-- 1 singh96 students 1.4K Sep 16 09:42 readme.txt


4.
IUPUI SHELL
 Enter the input: ps
   PID TTY          TIME CMD
193640 pts/3    00:00:00 bash
194985 pts/3    00:00:00 hw2
195398 pts/3    00:00:00 ps
195399 pts/3    00:00:00 ps

5.
 IUPUI SHELL                                                                     
 Enter the input: grep fprintf hw2.c
  fprintf(stderr, "performed" "\n");
6.
MULTIPLE COMMANDS 

IUPUI SHELL                                                                      
Enter the input: grep fprintf hw2.c | sort hw2.c
hw2.c:      fprintf(stderr, "performed" "\n");
sort:      fprintf(stderr, "performed" "\n");
performed

ERROR CASES
7.IUPUI SHELL									  // output should be in the last and input at starting 
 Enter the input: output > a.txt | cat
Error : input redirct after a pip; make sure only the last subcommand have >
